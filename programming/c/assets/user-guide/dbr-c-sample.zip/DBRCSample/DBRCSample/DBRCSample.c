#include <stdio.h>
#include "../../Include/DynamsoftBarcodeReader.h"
#if defined(_WIN64) || defined(_WIN32)
#ifdef _WIN64
#pragma comment(lib, "../../Lib/Windows/x64/DBRx64.lib")
#else
#pragma comment(lib, "../../Lib/Windows/x86/DBRx86.lib")
#endif
#endif

void main()
{
    void* hBarcode = NULL;
    char sError[512];
    PublicRuntimeSettings runtimeSettings;
    TextResultArray* pResult = NULL;
	int iErrorCode = -1;
	int iIndex;

	hBarcode = DBR_CreateInstance();

	DBR_InitLicense(hBarcode, "<insert DBR license key here>");

    DBR_GetRuntimeSettings(hBarcode, &runtimeSettings);
    runtimeSettings.barcodeFormatIds = BF_ALL;
    runtimeSettings.barcodeFormatIds_2 = BF2_POSTALCODE | BF2_DOTCODE;
    runtimeSettings.expectedBarcodesCount = 32;
    DBR_UpdateRuntimeSettings(hBarcode, &runtimeSettings, sError, 512);

    iErrorCode = DBR_DecodeFile(hBarcode, "../../Images/AllSupportedBarcodeTypes.png", "");
    if (iErrorCode != DBR_OK)
        printf("%s\n", DBR_GetErrorString(iErrorCode));

    DBR_GetAllTextResults(hBarcode, &pResult);
    if (pResult != NULL && pResult->resultsCount > 0)
    {
        printf("%d total barcode(s) found. \n", pResult->resultsCount);
        for (iIndex = 0; iIndex < pResult->resultsCount; iIndex++)
        {
            printf("Result %d\n", iIndex + 1);
            printf("Barcode Format: %s\n", pResult->results[iIndex]->barcodeFormatString);
            printf("Barcode Text: %s \n", pResult->results[iIndex]->barcodeText);
        }
    }
    getchar();

    if (pResult != NULL)
        DBR_FreeTextResults(&pResult);
    DBR_DestroyInstance(hBarcode);
}