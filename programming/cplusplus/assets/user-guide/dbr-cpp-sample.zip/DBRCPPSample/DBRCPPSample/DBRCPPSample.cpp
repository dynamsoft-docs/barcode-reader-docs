#include<iostream>
#include "../../Include/DynamsoftBarcodeReader.h"
using namespace std;
using namespace dynamsoft::dbr;
#if defined(_WIN64) || defined(_WIN32)
#ifdef _WIN64
#pragma comment(lib, "../../Lib/Windows/x64/DBRx64.lib")
#else
#pragma comment(lib, "../../Lib/Windows/x86/DBRx86.lib")
#endif
#endif

int main()
{
    CBarcodeReader dbr;

    dbr.InitLicense("<insert DBR license key here>");

    char sError[512];
    PublicRuntimeSettings runtimeSettings;
    dbr.GetRuntimeSettings(&runtimeSettings);
    runtimeSettings.barcodeFormatIds = BF_ALL;
    runtimeSettings.barcodeFormatIds_2 = BF2_POSTALCODE | BF2_DOTCODE;
    runtimeSettings.expectedBarcodesCount = 32;
    dbr.UpdateRuntimeSettings(&runtimeSettings, sError, 512);

    int iErrorCode = -1;
    iErrorCode = dbr.DecodeFile("../AllSupportedBarcodeTypes.png", "");
    if (iErrorCode != DBR_OK)
        cout << dbr.GetErrorString(iErrorCode) << endl;

    TextResultArray* pResult = NULL;
    dbr.GetAllTextResults(&pResult);
    if (pResult != NULL && pResult->resultsCount > 0)
    {
        cout << pResult->resultsCount <<" total barcode(s) found."<< endl;
        for (int iIndex = 0; iIndex < pResult->resultsCount; iIndex++)
        {
            cout << "Result " << iIndex + 1 << endl;
            cout << "Barcode Format: " << pResult->results[iIndex]->barcodeFormatString << endl;
            cout << "Barcode Text: " << pResult->results[iIndex]->barcodeText << endl;
        }
    }
    cin.ignore();

    if (pResult != NULL)
        CBarcodeReader::FreeTextResults(&pResult);
    return 0;
}