﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dynamsoft;
using Dynamsoft.DBR;

namespace DBRCSharpSample
{
    class Program
    {
        static void Main(string[] args)
        {
            BarcodeReader reader = new BarcodeReader("<your license key>");
            PublicRuntimeSettings runtimeSettings = reader.GetRuntimeSettings();
            runtimeSettings.BarcodeFormatIds = (int)EnumBarcodeFormat.BF_ALL;
            runtimeSettings.BarcodeFormatIds_2 = (int)(EnumBarcodeFormat_2.BF2_POSTALCODE | EnumBarcodeFormat_2.BF2_DOTCODE);
            runtimeSettings.ExpectedBarcodesCount = 32;
            reader.UpdateRuntimeSettings(runtimeSettings);

            TextResult[] results;
            try
            {
                results = reader.DecodeFile(@"..\Images\AllSupportedBarcodeTypes.png", "");
                Console.WriteLine("Total barcodes found: " + results.Length);
                for (int iIndex = 0; iIndex < results.Length; ++iIndex)
                {
                    Console.WriteLine("Barcode " + (iIndex + 1));
                    if (results[iIndex].BarcodeFormat != 0)
                    {
                        Console.WriteLine("    Barcode Format: " + results[iIndex].BarcodeFormatString);
                    }
                    else
                    {
                        Console.WriteLine("    Barcode Format: " + results[iIndex].BarcodeFormatString_2);
                    }
                    Console.WriteLine("    Barcode Text: " + results[iIndex].BarcodeText);
                }

            }
            catch (BarcodeReaderException exp)
            {
                Console.WriteLine(exp.Message);
            }
            reader.Dispose();
            Console.Read();
        }
    }
}
