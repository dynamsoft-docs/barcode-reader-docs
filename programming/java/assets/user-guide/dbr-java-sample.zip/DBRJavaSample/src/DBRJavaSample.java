import com.dynamsoft.dbr.*;
public class DBRJavaSample {
    public static void main(String[] args) throws Exception {
    	BarcodeReader reader = new BarcodeReader();
    	reader.initLicense("<insert DBR license key here>");
    	
        PublicRuntimeSettings runtimeSettings = reader.getRuntimeSettings();
        runtimeSettings.barcodeFormatIds = EnumBarcodeFormat.BF_ALL;
        runtimeSettings.barcodeFormatIds_2 = EnumBarcodeFormat_2.BF2_POSTALCODE | EnumBarcodeFormat_2.BF2_DOTCODE;
        runtimeSettings.expectedBarcodesCount = 32;
        reader.updateRuntimeSettings(runtimeSettings);

        TextResult[] results;
        try
        {
            results = reader.decodeFile("[INSTALLATION FOLDER]/images/AllSupportedBarcodeTypes.png", "");
            System.out.println("Total barcodes found: " + results.length);
            for (int iIndex = 0; iIndex < results.length; ++iIndex)
            {
                System.out.println("Barcode " + (iIndex + 1));
                if (results[iIndex].barcodeFormat != 0)
                {
                    System.out.println("    Barcode Format: " + results[iIndex].barcodeFormatString);
                }
                else
                {
                    System.out.println("    Barcode Format: " + results[iIndex].barcodeFormatString_2);
                }
                System.out.println("    Barcode Text: " + results[iIndex].barcodeText);
            }
     
        }
        catch (BarcodeReaderException exp)
        {
            System.out.println(exp.getMessage());
        }

        reader.destroy();
    }
}
