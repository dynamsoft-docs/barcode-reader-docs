import os
import sys
from dbr import *

reader = BarcodeReader()

reader.init_license("<insert DBR license key here>")

settings = reader.get_runtime_settings()
settings.barcode_format_ids = EnumBarcodeFormat.BF_ALL
settings.barcode_format_ids_2 = EnumBarcodeFormat_2.BF2_POSTALCODE | EnumBarcodeFormat_2.BF2_DOTCODE
settings.excepted_barcodes_count = 32
reader.update_runtime_settings(settings)

try:
   image = r"[INSTALLATION FOLDER]/Images/AllSupportedBarcodeTypes.png"
   text_results = reader.decode_file(image)
   if text_results != None:
      for text_result in text_results:
         print("Barcode Format : " + text_result.barcode_format_string)
         if len(text_result.barcode_format_string) == 0:
            print("Barcode Format : " + text_result.barcode_format_string_2)
         else:
            print("Barcode Format : " + text_result.barcode_format_string)
         print("Barcode Text : " + text_result.barcode_text)
except BarcodeReaderError as bre:
   print(bre)

del reader
